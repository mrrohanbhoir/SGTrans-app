"""Applies SGTrans settings to the Android project that `flutter create` generates.

Run from the project root after `flutter create`. Sets the app name, adds the
permissions GPS tracking needs, inserts the Google Maps key, and raises minSdk to 23
(required by Firebase).
"""
import os
import pathlib
import re

manifest = pathlib.Path("android/app/src/main/AndroidManifest.xml")
text = manifest.read_text()

text = re.sub(r'android:label="[^"]*"', 'android:label="SGTrans"', text, count=1)

permissions = [
    "INTERNET",
    "ACCESS_FINE_LOCATION",
    "ACCESS_COARSE_LOCATION",
    "FOREGROUND_SERVICE",
    "FOREGROUND_SERVICE_LOCATION",
    "POST_NOTIFICATIONS",
]
lines = "".join(
    f'    <uses-permission android:name="android.permission.{p}"/>\n'
    for p in permissions
    if f"android.permission.{p}" not in text
)
text = text.replace("<application", lines + "    <application", 1)

key = os.environ.get("MAPS_API_KEY", "")
meta = (
    '        <meta-data android:name="com.google.android.geo.API_KEY" '
    f'android:value="{key}"/>\n'
)
if "com.google.android.geo.API_KEY" not in text:
    text = text.replace("<activity", meta + "        <activity", 1)
manifest.write_text(text)

for name, replacement in (
    ("android/app/build.gradle.kts", "minSdk = 23"),
    ("android/app/build.gradle", "minSdkVersion 23"),
):
    path = pathlib.Path(name)
    if path.exists():
        gradle = path.read_text()
        gradle = re.sub(r"minSdk(?:Version)?\s*=?\s*flutter\.minSdkVersion", replacement, gradle)
        path.write_text(gradle)

if not key:
    print("Warning: MAPS_API_KEY is empty, so maps will show blank.")
print("Android project patched for SGTrans.")
