# SGTrans

One Android app for your trucking business, with live GPS tracking. After signing in with a mobile number, SGTrans opens the right screen for the person:

| Person | How the app knows | What they get |
|---|---|---|
| Owner | Their number has a document in `owners` | Live map of every running truck, create and delete trips |
| Driver | Their number is the driver on a trip | Assigned trips, **Start trip** (GPS sharing on), **Mark delivered** (GPS sharing off) |
| Customer | Everyone else | Their shipments, with a live map, route so far, speed and last update |

A trip lists the driver's number and the customer's number(s). Those numbers decide who can see or update it (`firestore.rules`).

> This code was written without being built or run. Expect to fix small things on the first build.

## Get the APK (no Flutter needed on your computer)

The file `.github/workflows/build-apk.yml` builds `SGTrans.apk` on GitHub for free. You need a GitHub account and about 30 minutes the first time.

### 1. Firebase
1. Create a project at console.firebase.google.com.
2. **Authentication → Sign-in method → Phone**: turn it on. While testing, add test phone numbers so you do not use real SMS.
3. **Firestore Database**: create it.
4. **Firestore → Rules**: paste the contents of `firestore.rules` and publish.
5. **Project settings → Your apps → Add app → Android**. Package name: `com.sgtrans.sgtrans`. Skip the other steps, then download `google-services.json`.
6. Open `lib/firebase_options.dart` and copy the five values from `google-services.json` into it. The file explains where each one is.
7. **Firestore → Start collection** named `owners`, with a document whose ID is your phone number in full, for example `+919876543210`. The fields can be empty.

### 2. A fixed signing key (needed for phone sign-in)
Firebase phone sign-in only works for apps whose signing fingerprint it knows. Make one key and keep it safe. On any computer with Java:

```
keytool -genkey -v -keystore sgtrans.keystore -alias androiddebugkey -storepass android -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=SGTrans"
keytool -list -v -keystore sgtrans.keystore -alias androiddebugkey -storepass android
base64 -w0 sgtrans.keystore > sgtrans.keystore.b64
```

- Copy the **SHA-1** and **SHA-256** lines into Firebase: Project settings → your Android app → Add fingerprint.
- Keep `sgtrans.keystore` backed up. If you lose it you cannot update an installed app.

### 3. Google Maps key
In Google Cloud console, create an API key and turn on **Maps SDK for Android**. Restrict it to package `com.sgtrans.sgtrans` and your SHA-1.

### 4. GitHub
1. Create a private repository and upload this whole folder to it (branch `main`).
2. Repository **Settings → Secrets and variables → Actions → New repository secret**:
   - `MAPS_API_KEY`: your Google Maps key
   - `SGTRANS_KEYSTORE_B64`: the contents of `sgtrans.keystore.b64`
3. **Actions → Build SGTrans APK → Run workflow**.
4. When it finishes (about 10 minutes), open the run and download the **SGTrans-apk** artifact. Unzip it to get `SGTrans.apk`.

### 5. Install
Send `SGTrans.apk` to a phone and open it. Android will ask to allow installs from that source. For Google Play you need an app bundle (`flutter build appbundle`) and a Play developer account, which can be added later.

## Using it
1. Open SGTrans with the number you added to `owners`, then **Trips → New trip**.
2. Enter the driver's number and the customer's number.
3. The driver signs in with their number and taps **Start trip**. Android asks for location permission and shows a "Trip in progress" notification.
4. The customer signs in with their number and opens the shipment to follow the truck.

## Building on your own computer instead
```
flutter create --org com.sgtrans --project-name sgtrans --platforms android .
rm test/widget_test.dart
MAPS_API_KEY=your_key python3 scripts/patch_android.py
flutter pub get
flutter build apk --release -t lib/main.dart
```
The APK is at `build/app/outputs/flutter-apk/app-release.apk`.

## Things to know
- **App icon.** It uses the default Flutter icon. Add `flutter_launcher_icons` with your logo to change it.
- **Cost.** SMS codes beyond the free quota, Maps loads and Firestore writes are billed. To cut writes, raise `distanceFilter` and the ping interval in `lib/driver/trip_tracker.dart`.
- **Battery.** Some phone makers stop background apps. Drivers may need to set SGTrans to "Unrestricted" battery use.
- **What customers can see.** Firestore rules cannot hide single fields, so a customer's phone can read the freight amount stored on their own trip. Move freight to an owner-only collection if that matters.
- **Not connected to the web Lorry Ledger page.** Trips are stored separately. Billing and expenses stay in the web page for now.
- **Privacy.** Tell drivers when their location is shared and that it stops on delivery.
- **Separate apps.** `lib/main_driver.dart`, `lib/main_customer.dart` and `lib/main_owner.dart` still build driver-only, customer-only and owner-only apps if you want them published separately later.
