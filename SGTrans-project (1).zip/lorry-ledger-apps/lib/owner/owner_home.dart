import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../core/live_map.dart';
import '../core/models.dart';
import 'new_trip.dart';

/// Owner app: live map of every running truck, plus trip creation.
/// Only phone numbers that have a document at owners/<number> get in.
class OwnerHome extends StatelessWidget {
  const OwnerHome({super.key, required this.user});
  final User user;

  @override
  Widget build(BuildContext context) {
    final phone = user.phoneNumber ?? '';
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: FirebaseFirestore.instance.collection('owners').doc(phone).get(),
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError || !(snap.data?.exists ?? false)) {
          return Scaffold(
            appBar: AppBar(title: const Text('SGTrans Owner')),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('$phone is not set up as an owner.', textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Sign out')),
                  ],
                ),
              ),
            ),
          );
        }
        return const _OwnerShell();
      },
    );
  }
}

class _OwnerShell extends StatefulWidget {
  const _OwnerShell();
  @override
  State<_OwnerShell> createState() => _OwnerShellState();
}

class _OwnerShellState extends State<_OwnerShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_tab == 0 ? 'Fleet on the road' : 'Trips'),
        actions: [
          IconButton(tooltip: 'Sign out', icon: const Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut()),
        ],
      ),
      body: _tab == 0 ? const _FleetMap() : const _TripList(),
      floatingActionButton: _tab == 1
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NewTripScreen())),
              icon: const Icon(Icons.add),
              label: const Text('New trip'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Live map'),
          NavigationDestination(icon: Icon(Icons.list_alt_outlined), selectedIcon: Icon(Icons.list_alt), label: 'Trips'),
        ],
      ),
    );
  }
}

class _FleetMap extends StatelessWidget {
  const _FleetMap();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: tripsRef.where('status', isEqualTo: 'running').snapshots(),
      builder: (context, snap) {
        final trips = (snap.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[]).map(Trip.fromDoc).toList();
        final markers = <Marker>{
          for (final t in trips)
            if (t.live != null)
              Marker(
                markerId: MarkerId(t.id),
                position: LatLng(t.live!.lat, t.live!.lng),
                infoWindow: InfoWindow(
                  title: t.vehicleReg.isEmpty ? t.lr : t.vehicleReg,
                  snippet: '${t.from} → ${t.to} · ${ago(t.live!.at)}',
                ),
              ),
        };
        return Stack(
          children: [
            LiveMap(markers: markers),
            if (trips.isEmpty && snap.hasData)
              const Positioned(
                left: 16,
                right: 16,
                top: 16,
                child: Card(child: Padding(padding: EdgeInsets.all(14), child: Text('No trucks are on the road right now.'))),
              ),
          ],
        );
      },
    );
  }
}

class _TripList extends StatelessWidget {
  const _TripList();

  Future<void> _confirmDelete(BuildContext context, Trip t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Delete ${t.lr}?'),
        content: const Text('The trip and its route history will no longer be shown to the driver or customer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) await tripsRef.doc(t.id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: tripsRef.orderBy('createdAt', descending: true).limit(100).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('Could not load trips.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final trips = snap.data!.docs.map(Trip.fromDoc).toList();
        if (trips.isEmpty) return const Center(child: Text('No trips yet. Tap New trip to add one.'));
        return ListView(
          padding: const EdgeInsets.only(top: 8, bottom: 88),
          children: [
            for (final t in trips)
              Card(
                child: ListTile(
                  title: Text('${t.from} → ${t.to}'),
                  subtitle: Text('${t.lr} · ${t.party}\n${t.vehicleReg.isEmpty ? 'No vehicle' : t.vehicleReg} · driver ${t.driverPhone}'),
                  isThreeLine: true,
                  trailing: Chip(label: Text(t.statusLabel), visualDensity: VisualDensity.compact),
                  onLongPress: () => _confirmDelete(context, t),
                ),
              ),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('Press and hold a trip to delete it.', textAlign: TextAlign.center),
            ),
          ],
        );
      },
    );
  }
}
