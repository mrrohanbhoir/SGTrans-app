import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../core/models.dart';

class NewTripScreen extends StatefulWidget {
  const NewTripScreen({super.key});
  @override
  State<NewTripScreen> createState() => _NewTripScreenState();
}

class _NewTripScreenState extends State<NewTripScreen> {
  final _form = GlobalKey<FormState>();
  final _lr = TextEditingController();
  final _party = TextEditingController();
  final _from = TextEditingController();
  final _to = TextEditingController();
  final _material = TextEditingController();
  final _vehicle = TextEditingController();
  final _driver = TextEditingController();
  final _customers = TextEditingController();
  final _freight = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    for (final c in [_lr, _party, _from, _to, _material, _vehicle, _driver, _customers, _freight]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _required(String? v) => (v == null || v.trim().isEmpty) ? 'Required' : null;

  String? _phoneCheck(String? v) {
    if (v == null || v.trim().isEmpty) return 'Required';
    for (final p in v.split(',')) {
      if (normalizePhone(p).length < 12) return 'Enter 10 digit mobile numbers';
    }
    return null;
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await tripsRef.add({
        'lr': _lr.text.trim(),
        'party': _party.text.trim(),
        'from': _from.text.trim(),
        'to': _to.text.trim(),
        'material': _material.text.trim(),
        'vehicleReg': _vehicle.text.trim().toUpperCase(),
        'driverPhone': normalizePhone(_driver.text),
        'customerPhones': _customers.text.split(',').where((s) => s.trim().isNotEmpty).map(normalizePhone).toList(),
        'freight': double.tryParse(_freight.text.trim()) ?? 0,
        'status': 'planned',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the trip.')));
    }
  }

  Widget _field(TextEditingController c, String label, {String? Function(String?)? validator = null, TextInputType? type, String? helper}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextFormField(
        controller: c,
        keyboardType: type,
        validator: validator,
        decoration: InputDecoration(labelText: label, helperText: helper),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New trip')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field(_lr, 'LR number', validator: _required),
            _field(_party, 'Party (customer name)', validator: _required),
            _field(_from, 'From', validator: _required),
            _field(_to, 'To', validator: _required),
            _field(_material, 'Material'),
            _field(_vehicle, 'Vehicle registration', helper: 'For example MH 12 AB 1234'),
            _field(_driver, 'Driver mobile number', validator: _phoneCheck, type: TextInputType.phone, helper: 'The driver signs in with this number'),
            _field(_customers, 'Customer mobile number(s)', validator: _phoneCheck, type: TextInputType.phone, helper: 'Separate several numbers with commas'),
            _field(_freight, 'Freight (₹)', type: TextInputType.number),
            const SizedBox(height: 8),
            FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'Saving…' : 'Create trip')),
          ],
        ),
      ),
    );
  }
}
