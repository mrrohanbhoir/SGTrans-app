import 'core/app.dart';
import 'driver/driver_home.dart';

// Run with: flutter run -t lib/main_driver.dart
Future<void> main() => bootApp(title: 'SGTrans Driver', home: (user) => DriverHome(user: user));
