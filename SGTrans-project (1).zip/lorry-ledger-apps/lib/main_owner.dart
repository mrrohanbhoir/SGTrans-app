import 'core/app.dart';
import 'owner/owner_home.dart';

// Run with: flutter run -t lib/main_owner.dart
Future<void> main() => bootApp(title: 'SGTrans Owner', home: (user) => OwnerHome(user: user));
