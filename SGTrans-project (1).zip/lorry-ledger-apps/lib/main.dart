import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'core/app.dart';
import 'core/models.dart';
import 'customer/customer_home.dart';
import 'driver/driver_home.dart';
import 'owner/owner_home.dart';

// The single SGTrans app. After sign-in it opens the right screen for the person:
//   owner    -> has a document at owners/<their number>
//   driver   -> is the driver on at least one trip
//   customer -> everyone else
// (main_driver.dart, main_customer.dart and main_owner.dart still exist if you
// ever want to publish them as three separate apps.)
Future<void> main() => bootApp(title: 'SGTrans', home: (user) => RoleGate(user: user));

class RoleGate extends StatefulWidget {
  const RoleGate({super.key, required this.user});
  final User user;

  @override
  State<RoleGate> createState() => _RoleGateState();
}

class _RoleGateState extends State<RoleGate> {
  late Future<String> _role = _detect();

  Future<String> _detect() async {
    final phone = widget.user.phoneNumber ?? '';
    var reachedServer = false;
    try {
      final owner = await FirebaseFirestore.instance.collection('owners').doc(phone).get();
      reachedServer = true;
      if (owner.exists) return 'owner';
    } catch (_) {}
    try {
      final asDriver = await tripsRef.where('driverPhone', isEqualTo: phone).limit(1).get();
      reachedServer = true;
      if (asDriver.docs.isNotEmpty) return 'driver';
    } catch (_) {}
    if (!reachedServer) throw StateError('offline');
    return 'customer';
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _role,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError) {
          return Scaffold(
            appBar: AppBar(title: const Text('SGTrans')),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Could not reach the server. Check your internet connection.', textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: () => setState(() => _role = _detect()), child: const Text('Try again')),
                  ],
                ),
              ),
            ),
          );
        }
        switch (snap.data) {
          case 'owner':
            return OwnerHome(user: widget.user);
          case 'driver':
            return DriverHome(user: widget.user);
          default:
            return CustomerHome(user: widget.user);
        }
      },
    );
  }
}
