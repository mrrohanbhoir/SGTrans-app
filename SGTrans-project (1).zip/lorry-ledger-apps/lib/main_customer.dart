import 'core/app.dart';
import 'customer/customer_home.dart';

// Run with: flutter run -t lib/main_customer.dart
Future<void> main() => bootApp(title: 'SGTrans Customer', home: (user) => CustomerHome(user: user));
