import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../core/models.dart';
import 'track_trip.dart';

class CustomerHome extends StatelessWidget {
  const CustomerHome({super.key, required this.user});
  final User user;

  @override
  Widget build(BuildContext context) {
    final phone = user.phoneNumber ?? '';
    return Scaffold(
      appBar: AppBar(
        title: const Text('My shipments'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            icon: const Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: tripsRef.where('customerPhones', arrayContains: phone).snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Could not load shipments.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final trips = snap.data!.docs.map(Trip.fromDoc).toList();
          const order = {'running': 0, 'planned': 1, 'delivered': 2};
          trips.sort((a, b) => (order[a.status] ?? 3).compareTo(order[b.status] ?? 3));
          if (trips.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('No shipments are linked to $phone yet.\nAsk your transporter to add this number to your booking.', textAlign: TextAlign.center),
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.symmetric(vertical: 8),
            children: [
              for (final t in trips)
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    title: Text('${t.from} → ${t.to}', style: Theme.of(context).textTheme.titleLarge),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text('${t.lr}${t.material.isEmpty ? '' : ' · ${t.material}'}\n${t.statusLabel}'
                          '${t.status == 'running' ? ' · updated ${ago(t.live?.at)}' : ''}'),
                    ),
                    isThreeLine: true,
                    trailing: t.status == 'running' ? const Icon(Icons.local_shipping) : const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TrackTripScreen(tripId: t.id))),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
