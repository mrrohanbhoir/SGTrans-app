import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../core/live_map.dart';
import '../core/models.dart';

class TrackTripScreen extends StatelessWidget {
  const TrackTripScreen({super.key, required this.tripId});
  final String tripId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Track shipment')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: tripsRef.doc(tripId).snapshots(),
        builder: (context, tripSnap) {
          if (!tripSnap.hasData) return const Center(child: CircularProgressIndicator());
          final trip = Trip.fromDoc(tripSnap.data!);
          final live = trip.live;

          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: tripsRef.doc(tripId).collection('pings').orderBy('at').limitToLast(500).snapshots(),
            builder: (context, pingSnap) {
              final route = <LatLng>[
                for (final d in pingSnap.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[])
                  LatLng((d['lat'] as num).toDouble(), (d['lng'] as num).toDouble()),
              ];
              final markers = <Marker>{
                if (live != null)
                  Marker(
                    markerId: const MarkerId('truck'),
                    position: LatLng(live.lat, live.lng),
                    infoWindow: InfoWindow(title: trip.vehicleReg.isEmpty ? 'Truck' : trip.vehicleReg, snippet: trip.lr),
                  ),
              };
              return Column(
                children: [
                  Expanded(child: LiveMap(markers: markers, polyline: route)),
                  _InfoPanel(trip: trip),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({required this.trip});
  final Trip trip;

  @override
  Widget build(BuildContext context) {
    final live = trip.live;
    final String line;
    if (trip.status == 'delivered') {
      line = 'Delivered';
    } else if (trip.status == 'planned') {
      line = 'Not started yet';
    } else if (live == null) {
      line = 'Waiting for the first location from the driver';
    } else {
      line = 'On the road · ${live.speedKmh.round()} km/h · updated ${ago(live.at)}';
    }
    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        color: Theme.of(context).colorScheme.surface,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${trip.from} → ${trip.to}', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text('${trip.lr}${trip.vehicleReg.isEmpty ? '' : ' · ${trip.vehicleReg}'}'),
            const SizedBox(height: 8),
            Text(line, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
