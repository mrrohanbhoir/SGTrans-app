// TEMPLATE: replace every value marked REPLACE with the numbers from your own
// Firebase project, or overwrite this whole file by running `flutterfire configure`.
//
// Where to find them: Firebase console -> Project settings -> Your apps -> Android app
// (register the app with package name com.sgtrans.sgtrans first), then open the
// google-services.json it offers. The values below are inside that file:
//   apiKey            = client[0].api_key[0].current_key
//   appId             = client[0].client_info.mobilesdk_app_id
//   messagingSenderId = project_info.project_number
//   projectId         = project_info.project_id
//   storageBucket     = project_info.storage_bucket
//
// These values identify your project; they are not passwords. Access is controlled
// by firestore.rules.

import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => const FirebaseOptions(
        apiKey: 'REPLACE',
        appId: 'REPLACE',
        messagingSenderId: 'REPLACE',
        projectId: 'REPLACE',
        storageBucket: 'REPLACE',
      );
}
