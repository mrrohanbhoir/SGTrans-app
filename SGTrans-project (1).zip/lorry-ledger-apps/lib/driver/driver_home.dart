import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../core/models.dart';
import 'trip_tracker.dart';

class DriverHome extends StatefulWidget {
  const DriverHome({super.key, required this.user});
  final User user;

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final _tracker = TripTracker();
  bool _syncing = false;

  @override
  void dispose() {
    _tracker.stop();
    super.dispose();
  }

  /// Keeps GPS sharing in step with the trip list: on for the running trip,
  /// off otherwise. This also restarts sharing if the app is reopened mid-trip.
  void _syncTracker(List<Trip> trips) {
    if (_syncing) return;
    final running = trips.where((t) => t.status == 'running').toList();
    final wanted = running.isEmpty ? null : running.first.id;
    if (wanted == _tracker.activeTripId && (wanted == null || _tracker.isTracking)) return;
    _syncing = true;
    () async {
      if (wanted == null) {
        await _tracker.stop();
      } else {
        await _tracker.start(wanted);
      }
      if (mounted) setState(() => _syncing = false);
      _syncing = false;
    }();
  }

  void _say(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _start(Trip t, List<Trip> all) async {
    if (all.any((x) => x.status == 'running')) {
      _say('Finish your current trip before starting another.');
      return;
    }
    if (!await _tracker.ensurePermission()) {
      _say('Turn on location and allow it for this app to start the trip.');
      return;
    }
    try {
      await tripsRef.doc(t.id).update({'status': 'running', 'startedAt': FieldValue.serverTimestamp()});
    } catch (_) {
      _say('Could not start the trip. Check your connection.');
    }
  }

  Future<void> _deliver(Trip t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Delivered ${t.lr}?'),
        content: Text('This stops sharing your location with ${t.party}.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Not yet')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Mark delivered')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await tripsRef.doc(t.id).update({'status': 'delivered', 'deliveredAt': FieldValue.serverTimestamp()});
    } catch (_) {
      _say('Could not update the trip. Check your connection.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final phone = widget.user.phoneNumber ?? '';
    return Scaffold(
      appBar: AppBar(
        title: const Text('My trips'),
        actions: [
          IconButton(
            tooltip: 'Sign out',
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await _tracker.stop();
              await FirebaseAuth.instance.signOut();
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: tripsRef.where('driverPhone', isEqualTo: phone).snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Could not load trips.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final trips = snap.data!.docs.map(Trip.fromDoc).toList();
          const order = {'running': 0, 'planned': 1, 'delivered': 2};
          trips.sort((a, b) => (order[a.status] ?? 3).compareTo(order[b.status] ?? 3));
          WidgetsBinding.instance.addPostFrameCallback((_) => _syncTracker(trips));

          if (trips.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('No trips assigned to $phone yet.', textAlign: TextAlign.center),
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.symmetric(vertical: 8),
            children: [
              if (_tracker.isTracking)
                const ListTile(
                  leading: Icon(Icons.my_location, color: Colors.green),
                  title: Text('Sharing live location'),
                  subtitle: Text('Keep location turned on until you mark the trip delivered.'),
                ),
              for (final t in trips) _TripCard(trip: t, onStart: () => _start(t, trips), onDeliver: () => _deliver(t)),
            ],
          );
        },
      ),
    );
  }
}

class _TripCard extends StatelessWidget {
  const _TripCard({required this.trip, required this.onStart, required this.onDeliver});
  final Trip trip;
  final VoidCallback onStart;
  final VoidCallback onDeliver;

  @override
  Widget build(BuildContext context) {
    final t = trip;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(t.lr, style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w600)),
                const Spacer(),
                Chip(label: Text(t.statusLabel), visualDensity: VisualDensity.compact),
              ],
            ),
            Text('${t.from} → ${t.to}', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text('${t.party}${t.material.isEmpty ? '' : ' · ${t.material}'}'),
            if (t.vehicleReg.isNotEmpty) Text('Vehicle ${t.vehicleReg}'),
            const SizedBox(height: 12),
            if (t.status == 'planned')
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onStart, icon: const Icon(Icons.play_arrow), label: const Text('Start trip'))),
            if (t.status == 'running')
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onDeliver, icon: const Icon(Icons.check), label: const Text('Mark delivered'))),
          ],
        ),
      ),
    );
  }
}
