import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

import '../core/models.dart';

/// Streams the phone's GPS position into Firestore while a trip is running.
///
/// - Every fix updates `trips/<id>.live` (what the customer's marker follows).
/// - A breadcrumb is added to `trips/<id>/pings` at most once a minute
///   (what draws the route line), which keeps write volume low.
/// On Android the stream runs as a foreground service with a visible
/// notification, so it keeps working with the screen off.
class TripTracker {
  StreamSubscription<Position>? _sub;
  String? activeTripId;
  DateTime _lastPing = DateTime.fromMillisecondsSinceEpoch(0);

  bool get isTracking => _sub != null;

  Future<bool> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission == LocationPermission.whileInUse || permission == LocationPermission.always;
  }

  Future<void> start(String tripId) async {
    if (activeTripId == tripId && _sub != null) return;
    await stop();
    if (!await ensurePermission()) return;
    activeTripId = tripId;

    final LocationSettings settings = defaultTargetPlatform == TargetPlatform.android
        ? AndroidSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 25, // metres between updates
            intervalDuration: const Duration(seconds: 15),
            foregroundNotificationConfig: const ForegroundNotificationConfig(
              notificationTitle: 'Trip in progress',
              notificationText: 'Sharing live location with your transporter',
              enableWakeLock: true,
            ),
          )
        : AppleSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 25,
            activityType: ActivityType.automotiveNavigation,
            pauseLocationUpdatesAutomatically: false,
            showBackgroundLocationIndicator: true,
            allowBackgroundLocationUpdates: true,
          );

    _sub = Geolocator.getPositionStream(locationSettings: settings).listen(
      (p) => _push(tripId, p),
      onError: (Object e) => debugPrint('Location error: $e'),
    );
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    activeTripId = null;
  }

  Future<void> _push(String tripId, Position p) async {
    final kmh = (p.speed.isNaN || p.speed < 0) ? 0.0 : p.speed * 3.6;
    try {
      await tripsRef.doc(tripId).update({
        'live': {
          'lat': p.latitude,
          'lng': p.longitude,
          'speed': kmh,
          'heading': p.heading,
          'at': FieldValue.serverTimestamp(),
        },
      });
      final now = DateTime.now();
      if (now.difference(_lastPing) >= const Duration(seconds: 60)) {
        _lastPing = now;
        await tripsRef.doc(tripId).collection('pings').add({
          'lat': p.latitude,
          'lng': p.longitude,
          'at': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      // Offline or rules refused: the next fix tries again.
      debugPrint('Could not upload location: $e');
    }
  }
}
