import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'models.dart';

/// Phone number + one-time code sign-in. The phone number is the identity:
/// owners add it to a trip, and the rules match it against the signed-in user.
class PhoneAuthScreen extends StatefulWidget {
  const PhoneAuthScreen({super.key, required this.title});
  final String title;

  @override
  State<PhoneAuthScreen> createState() => _PhoneAuthScreenState();
}

class _PhoneAuthScreenState extends State<PhoneAuthScreen> {
  final _phone = TextEditingController();
  final _code = TextEditingController();
  String? _verificationId;
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _phone.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _sendCode() async {
    final number = normalizePhone(_phone.text);
    if (number.length < 12) {
      setState(() => _error = 'Enter a 10 digit mobile number.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: number,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async {
        await FirebaseAuth.instance.signInWithCredential(cred);
      },
      verificationFailed: (e) {
        if (!mounted) return;
        setState(() {
          _busy = false;
          _error = e.message ?? 'Could not send the code. Check the number and try again.';
        });
      },
      codeSent: (id, _) {
        if (!mounted) return;
        setState(() {
          _verificationId = id;
          _busy = false;
        });
      },
      codeAutoRetrievalTimeout: (id) => _verificationId ??= id,
    );
  }

  Future<void> _confirm() async {
    final id = _verificationId;
    if (id == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final cred = PhoneAuthProvider.credential(verificationId: id, smsCode: _code.text.trim());
      await FirebaseAuth.instance.signInWithCredential(cred);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = e.code == 'invalid-verification-code' ? 'That code is not right.' : (e.message ?? 'Sign-in failed.');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final waitingForCode = _verificationId != null;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 24),
            Text('Sign in', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 6),
            Text(waitingForCode
                ? 'Enter the 6 digit code sent to ${normalizePhone(_phone.text)}.'
                : 'Use the mobile number your transporter has on file.'),
            const SizedBox(height: 20),
            if (!waitingForCode)
              TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                autofillHints: const [AutofillHints.telephoneNumber],
                decoration: const InputDecoration(labelText: 'Mobile number', prefixText: '+91  '),
                onSubmitted: (_) => _sendCode(),
              )
            else
              TextField(
                controller: _code,
                keyboardType: TextInputType.number,
                maxLength: 6,
                autofillHints: const [AutofillHints.oneTimeCode],
                decoration: const InputDecoration(labelText: 'Code'),
                onSubmitted: (_) => _confirm(),
              ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _busy ? null : (waitingForCode ? _confirm : _sendCode),
              child: Text(_busy ? 'Please wait…' : (waitingForCode ? 'Confirm code' : 'Send code')),
            ),
            if (waitingForCode)
              TextButton(
                onPressed: _busy ? null : () => setState(() {
                  _verificationId = null;
                  _code.clear();
                }),
                child: const Text('Use a different number'),
              ),
          ],
        ),
      ),
    );
  }
}
