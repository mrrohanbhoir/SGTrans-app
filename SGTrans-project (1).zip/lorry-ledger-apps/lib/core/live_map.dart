import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

/// Thin wrapper around GoogleMap that follows a set of markers.
/// With one marker it keeps the camera centred on it; with several it fits them all.
class LiveMap extends StatefulWidget {
  const LiveMap({super.key, required this.markers, this.polyline = const [], this.follow = true});
  final Set<Marker> markers;
  final List<LatLng> polyline;
  final bool follow;

  @override
  State<LiveMap> createState() => _LiveMapState();
}

class _LiveMapState extends State<LiveMap> {
  GoogleMapController? _ctrl;
  String _lastKey = '';

  static const _india = CameraPosition(target: LatLng(20.5937, 78.9629), zoom: 4.6);

  void _moveCamera() {
    final c = _ctrl;
    if (c == null || !widget.follow || widget.markers.isEmpty) return;
    final key = widget.markers.map((m) => '${m.position.latitude.toStringAsFixed(4)},${m.position.longitude.toStringAsFixed(4)}').join('|');
    if (key == _lastKey) return;
    _lastKey = key;
    final points = widget.markers.map((m) => m.position).toList();
    if (points.length == 1) {
      c.animateCamera(CameraUpdate.newLatLngZoom(points.first, 14));
      return;
    }
    var south = points.first.latitude, north = south, west = points.first.longitude, east = west;
    for (final p in points) {
      if (p.latitude < south) south = p.latitude;
      if (p.latitude > north) north = p.latitude;
      if (p.longitude < west) west = p.longitude;
      if (p.longitude > east) east = p.longitude;
    }
    c.animateCamera(CameraUpdate.newLatLngBounds(
      LatLngBounds(southwest: LatLng(south, west), northeast: LatLng(north, east)),
      64,
    ));
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) => _moveCamera());
    return GoogleMap(
      initialCameraPosition: _india,
      markers: widget.markers,
      polylines: {
        if (widget.polyline.length > 1)
          Polyline(
            polylineId: const PolylineId('route'),
            points: widget.polyline,
            width: 5,
            color: Theme.of(context).colorScheme.primary,
          ),
      },
      myLocationButtonEnabled: false,
      zoomControlsEnabled: true,
      onMapCreated: (c) {
        _ctrl = c;
        _moveCamera();
      },
    );
  }
}
