import 'package:cloud_firestore/cloud_firestore.dart';

final tripsRef = FirebaseFirestore.instance.collection('trips');

/// Turns "98765 43210" or "09876543210" into "+919876543210".
/// Numbers that already start with "+" are kept as typed (digits only after the plus).
String normalizePhone(String input) {
  final trimmed = input.trim();
  final digits = trimmed.replaceAll(RegExp(r'[^0-9]'), '');
  if (trimmed.startsWith('+')) return '+$digits';
  final local = digits.length > 10 ? digits.substring(digits.length - 10) : digits;
  return '+91$local';
}

class LiveFix {
  LiveFix({required this.lat, required this.lng, required this.speedKmh, required this.heading, this.at});

  final double lat;
  final double lng;
  final double speedKmh;
  final double heading;
  final DateTime? at;

  factory LiveFix.fromMap(Map<String, dynamic> m) => LiveFix(
        lat: (m['lat'] ?? 0).toDouble(),
        lng: (m['lng'] ?? 0).toDouble(),
        speedKmh: (m['speed'] ?? 0).toDouble(),
        heading: (m['heading'] ?? 0).toDouble(),
        at: (m['at'] as Timestamp?)?.toDate(),
      );
}

class Trip {
  Trip({
    required this.id,
    required this.lr,
    required this.party,
    required this.from,
    required this.to,
    required this.material,
    required this.vehicleReg,
    required this.driverPhone,
    required this.customerPhones,
    required this.status,
    required this.freight,
    this.live,
  });

  final String id;
  final String lr;
  final String party;
  final String from;
  final String to;
  final String material;
  final String vehicleReg;
  final String driverPhone;
  final List<String> customerPhones;
  final String status; // planned | running | delivered
  final double freight;
  final LiveFix? live;

  factory Trip.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? <String, dynamic>{};
    final live = m['live'] as Map<String, dynamic>?;
    return Trip(
      id: d.id,
      lr: (m['lr'] ?? '') as String,
      party: (m['party'] ?? '') as String,
      from: (m['from'] ?? '') as String,
      to: (m['to'] ?? '') as String,
      material: (m['material'] ?? '') as String,
      vehicleReg: (m['vehicleReg'] ?? '') as String,
      driverPhone: (m['driverPhone'] ?? '') as String,
      customerPhones: List<String>.from(m['customerPhones'] ?? const <String>[]),
      status: (m['status'] ?? 'planned') as String,
      freight: (m['freight'] ?? 0).toDouble(),
      live: live == null ? null : LiveFix.fromMap(live),
    );
  }

  String get statusLabel =>
      status == 'running' ? 'On the road' : status == 'delivered' ? 'Delivered' : 'Planned';
}

String ago(DateTime? t) {
  if (t == null) return 'no location yet';
  final s = DateTime.now().difference(t).inSeconds;
  if (s < 60) return 'just now';
  if (s < 3600) return '${s ~/ 60} min ago';
  if (s < 86400) return '${s ~/ 3600} h ago';
  return '${s ~/ 86400} d ago';
}
